import asyncio
import random
import sys
import pygame

# --- Constants ---
CELL = 20
COLS = 30
ROWS = 30
WIDTH = COLS * CELL
HEIGHT = ROWS * CELL + 44
FPS = 10

# Palette
BG = (15, 15, 20)
GRID = (25, 25, 35)
SNAKE_H = (80, 220, 80)
SNAKE_B = (40, 160, 40)
FOOD_COL = (220, 60, 60)
TEXT_COL = (200, 200, 200)
DIM_COL = (70, 70, 90)
OVER_COL = (220, 80, 80)
HINT_COL = (140, 140, 160)

UP = (0, -1)
DOWN = (0, 1)
LEFT = (-1, 0)
RIGHT = (1, 0)

_PF = {
    '0': [0b01110, 0b10001, 0b10011, 0b10101, 0b11001, 0b10001, 0b01110],
    '1': [0b00100, 0b01100, 0b00100, 0b00100, 0b00100, 0b00100, 0b01110],
    '2': [0b01110, 0b10001, 0b00001, 0b00110, 0b01000, 0b10000, 0b11111],
    '3': [0b01110, 0b10001, 0b00001, 0b00110, 0b00001, 0b10001, 0b01110],
    '4': [0b10010, 0b10010, 0b10010, 0b11111, 0b00010, 0b00010, 0b00010],
    '5': [0b11111, 0b10000, 0b10000, 0b01110, 0b00001, 0b10001, 0b01110],
    '6': [0b01110, 0b10000, 0b10000, 0b11110, 0b10001, 0b10001, 0b01110],
    '7': [0b11111, 0b00001, 0b00010, 0b00100, 0b01000, 0b01000, 0b01000],
    '8': [0b01110, 0b10001, 0b10001, 0b01110, 0b10001, 0b10001, 0b01110],
    '9': [0b01110, 0b10001, 0b10001, 0b01111, 0b00001, 0b00001, 0b01110],
    'A': [0b01110, 0b10001, 0b10001, 0b11111, 0b10001, 0b10001, 0b10001],
    'B': [0b11110, 0b10001, 0b10001, 0b11110, 0b10001, 0b10001, 0b11110],
    'C': [0b01110, 0b10001, 0b10000, 0b10000, 0b10000, 0b10001, 0b01110],
    'D': [0b11100, 0b10010, 0b10001, 0b10001, 0b10001, 0b10010, 0b11100],
    'E': [0b11111, 0b10000, 0b10000, 0b11110, 0b10000, 0b10000, 0b11111],
    'F': [0b11111, 0b10000, 0b10000, 0b11110, 0b10000, 0b10000, 0b10000],
    'G': [0b01110, 0b10001, 0b10000, 0b10111, 0b10001, 0b10001, 0b01110],
    'I': [0b01110, 0b00100, 0b00100, 0b00100, 0b00100, 0b00100, 0b01110],
    'L': [0b10000, 0b10000, 0b10000, 0b10000, 0b10000, 0b10000, 0b11111],
    'M': [0b10001, 0b11011, 0b10101, 0b10001, 0b10001, 0b10001, 0b10001],
    'N': [0b10001, 0b11001, 0b10101, 0b10101, 0b10011, 0b10001, 0b10001],
    'O': [0b01110, 0b10001, 0b10001, 0b10001, 0b10001, 0b10001, 0b01110],
    'P': [0b11110, 0b10001, 0b10001, 0b11110, 0b10000, 0b10000, 0b10000],
    'Q': [0b01110, 0b10001, 0b10001, 0b10001, 0b10101, 0b10010, 0b01101],
    'R': [0b11110, 0b10001, 0b10001, 0b11110, 0b10100, 0b10010, 0b10001],
    'S': [0b01110, 0b10001, 0b10000, 0b01110, 0b00001, 0b10001, 0b01110],
    'T': [0b11111, 0b00100, 0b00100, 0b00100, 0b00100, 0b00100, 0b00100],
    'U': [0b10001, 0b10001, 0b10001, 0b10001, 0b10001, 0b10001, 0b01110],
    'V': [0b10001, 0b10001, 0b10001, 0b10001, 0b01010, 0b01010, 0b00100],
    'W': [0b10001, 0b10001, 0b10001, 0b10101, 0b10101, 0b10101, 0b01010],
    'Y': [0b10001, 0b10001, 0b01010, 0b00100, 0b00100, 0b00100, 0b00100],
    'Z': [0b11111, 0b00001, 0b00010, 0b00100, 0b01000, 0b10000, 0b11111],
    '!': [0b00100, 0b00100, 0b00100, 0b00100, 0b00100, 0b00000, 0b00100],
    ':': [0b00000, 0b00100, 0b00100, 0b00000, 0b00100, 0b00100, 0b00000],
    '-': [0b00000, 0b00000, 0b00000, 0b11111, 0b00000, 0b00000, 0b00000],
    ' ': [0b00000] * 7,
}

ADJECTIVES = ["AMAZING!!", "SUPERB!!", "GREAT!!", "AWESOME!!", "INSANE!!", "PERFECT!!", "BRILLIANT!!"]
CONFETTI_COLORS = [
    (255, 80, 80), (255, 180, 40), (80, 220, 80),
    (80, 180, 255), (200, 80, 255), (255, 80, 180),
]
FIREWORK_COLORS = [
    (255, 255, 100), (255, 100, 100), (100, 200, 255),
    (255, 100, 255), (100, 255, 150), (255, 180, 50),
]


def px_char(surf, ch, x, y, color, s=2):
    bm = _PF.get(ch.upper(), _PF[' '])
    for ri, row in enumerate(bm):
        for ci in range(5):
            if row & (1 << (4 - ci)):
                pygame.draw.rect(surf, color, (x + ci * s, y + ri * s, s, s))


def px_text(surf, text, x, y, color, s=2):
    for ch in text:
        px_char(surf, ch, x, y, color, s)
        x += (5 + 1) * s
    return x


def px_width(text, s=2):
    return len(text) * (5 + 1) * s


def draw_cell(surf, color, col, row, shrink=2):
    x = col * CELL + shrink
    y = row * CELL + 44 + shrink
    pygame.draw.rect(surf, color, (x, y, CELL - shrink * 2, CELL - shrink * 2))


def random_food(snake):
    while True:
        pos = (random.randint(0, COLS - 1), random.randint(0, ROWS - 1))
        if pos not in snake:
            return pos


def spawn_confetti():
    particles = []
    for _ in range(120):
        particles.append({
            'x': random.uniform(0, WIDTH),
            'y': random.uniform(-HEIGHT * 0.5, 0),
            'vx': random.uniform(-2, 2),
            'vy': random.uniform(3, 7),
            'w': random.randint(4, 8),
            'h': random.randint(4, 8),
            'color': random.choice(CONFETTI_COLORS),
            'life': random.randint(40, 70),
        })
    return particles


def update_draw_confetti(screen, particles):
    for p in particles:
        p['x'] += p['vx']
        p['y'] += p['vy']
        p['vy'] += 0.2
        p['life'] -= 1
        pygame.draw.rect(screen, p['color'], (int(p['x']), int(p['y']), p['w'], p['h']))
    particles[:] = [p for p in particles if p['life'] > 0]


def spawn_fireworks():
    import math
    particles = []
    burst_positions = [
        (WIDTH * 0.25, HEIGHT * 0.3),
        (WIDTH * 0.75, HEIGHT * 0.3),
        (WIDTH * 0.5, HEIGHT * 0.5),
        (WIDTH * 0.2, HEIGHT * 0.6),
        (WIDTH * 0.8, HEIGHT * 0.55),
    ]
    for bx, by in burst_positions:
        color = random.choice(FIREWORK_COLORS)
        count = 36
        for i in range(count):
            angle = (2 * math.pi / count) * i
            speed = random.uniform(3, 8)
            particles.append({
                'x': bx,
                'y': by,
                'vx': math.cos(angle) * speed,
                'vy': math.sin(angle) * speed,
                'color': color,
                'life': random.randint(20, 35),
                'size': random.randint(3, 5),
            })
    return particles


def update_draw_fireworks(screen, particles):
    for p in particles:
        p['x'] += p['vx']
        p['y'] += p['vy']
        p['vy'] += 0.3
        p['vx'] *= 0.96
        p['life'] -= 1
        pygame.draw.rect(screen, p['color'], (int(p['x']), int(p['y']), p['size'], p['size']))
    particles[:] = [p for p in particles if p['life'] > 0]


def draw_grid(screen):
    for c in range(COLS):
        for r in range(ROWS):
            pygame.draw.rect(
                screen,
                GRID,
                (c * CELL + CELL // 2 - 1, r * CELL + 44 + CELL // 2 - 1, 2, 2),
            )


def draw_title_screen(screen):
    screen.fill(BG)
    draw_grid(screen)

    title = "SNAKE"
    subtitle = "WEB DEMO"
    start = "PRESS ENTER TO START"
    controls1 = "ARROWS OR WASD TO MOVE"
    controls2 = "SPACE TO PAUSE"
    goal = "10 MINUTES MAX PER PLAY"

    px_text(screen, title, (WIDTH - px_width(title, 4)) // 2, 120, TEXT_COL, s=4)
    px_text(screen, subtitle, (WIDTH - px_width(subtitle, 2)) // 2, 175, DIM_COL, s=2)
    px_text(screen, start, (WIDTH - px_width(start, 2)) // 2, 250, HINT_COL, s=2)
    px_text(screen, controls1, (WIDTH - px_width(controls1, 2)) // 2, 310, TEXT_COL, s=2)
    px_text(screen, controls2, (WIDTH - px_width(controls2, 2)) // 2, 340, TEXT_COL, s=2)
    px_text(screen, goal, (WIDTH - px_width(goal, 2)) // 2, 390, OVER_COL, s=2)

    pygame.display.flip()


def draw_game(screen, snake, food, score, tries, confetti, fireworks, adjective, adj_timer, flash, elapsed_seconds):
    screen.fill(BG)
    draw_grid(screen)
    draw_cell(screen, FOOD_COL, food[0], food[1], shrink=4)

    for i, seg in enumerate(snake):
        draw_cell(screen, SNAKE_H if i == 0 else SNAKE_B, seg[0], seg[1])

    if confetti:
        update_draw_confetti(screen, confetti)
    if fireworks:
        update_draw_fireworks(screen, fireworks)

    if adj_timer > 0:
        ax = (WIDTH - px_width(adjective, s=3)) // 2
        ay = HEIGHT // 2 - 40
        px_text(screen, adjective, ax, ay, (255, 210, 60), s=3)

    if flash > 0:
        alpha = int((flash / 12) * 220)
        overlay = pygame.Surface((WIDTH, HEIGHT), pygame.SRCALPHA)
        overlay.fill((255, 255, 255, alpha))
        screen.blit(overlay, (0, 0))

    score_str = f"SCORE  {score}"
    px_text(screen, score_str, 10, 14, TEXT_COL, s=2)

    tries_str = f"TRY  {tries}"
    px_text(screen, tries_str, WIDTH - px_width(tries_str, s=2) - 10, 14, DIM_COL, s=2)

    time_str = f"TIME  {elapsed_seconds:03d}"
    px_text(screen, time_str, (WIDTH - px_width(time_str, s=2)) // 2, 14, HINT_COL, s=2)

    pygame.display.flip()


def draw_game_over(screen, score):
    overlay = pygame.Surface((WIDTH, HEIGHT), pygame.SRCALPHA)
    overlay.fill((0, 0, 0, 170))
    screen.blit(overlay, (0, 0))

    cy = HEIGHT // 2
    title = "GAME OVER"
    tx = (WIDTH - px_width(title, s=3)) // 2
    px_text(screen, title, tx, cy - 60, OVER_COL, s=3)

    sc_str = f"SCORE  {score}"
    sx = (WIDTH - px_width(sc_str, s=2)) // 2
    px_text(screen, sc_str, sx, cy - 10, TEXT_COL, s=2)

    hint = "R RETRY   Q QUIT"
    hx = (WIDTH - px_width(hint, s=2)) // 2
    px_text(screen, hint, hx, cy + 30, HINT_COL, s=2)
    pygame.display.flip()


async def wait_for_start():
    while True:
        for e in pygame.event.get():
            if e.type == pygame.QUIT:
                return False
            if e.type == pygame.KEYDOWN and e.key in (pygame.K_RETURN, pygame.K_SPACE):
                return True
        await asyncio.sleep(0)


async def wait_game_over_action(clock):
    while True:
        clock.tick(30)
        for e in pygame.event.get():
            if e.type == pygame.QUIT:
                return "quit"
            if e.type == pygame.KEYDOWN:
                if e.key == pygame.K_r:
                    return "retry"
                if e.key == pygame.K_q:
                    return "quit"
        await asyncio.sleep(0)


async def run_game(screen, tries):
    snake = [(COLS // 2, ROWS // 2)]
    direction = RIGHT
    next_dir = RIGHT
    food = random_food(snake)
    score = 0
    paused = False
    confetti = []
    celebrated = False
    flash = 0
    flashed = False
    fireworks = []
    fw_triggered = False
    adjective = ""
    adj_timer = 0
    last_milestone = 0
    clock = pygame.time.Clock()
    start_ticks = pygame.time.get_ticks()
    max_seconds = 600

    while True:
        clock.tick(FPS)
        elapsed_seconds = (pygame.time.get_ticks() - start_ticks) // 1000

        for e in pygame.event.get():
            if e.type == pygame.QUIT:
                return score, "quit"
            if e.type == pygame.KEYDOWN:
                if e.key == pygame.K_SPACE:
                    paused = not paused
                elif not paused:
                    if e.key in (pygame.K_UP, pygame.K_w) and direction != DOWN:
                        next_dir = UP
                    elif e.key in (pygame.K_DOWN, pygame.K_s) and direction != UP:
                        next_dir = DOWN
                    elif e.key in (pygame.K_LEFT, pygame.K_a) and direction != RIGHT:
                        next_dir = LEFT
                    elif e.key in (pygame.K_RIGHT, pygame.K_d) and direction != LEFT:
                        next_dir = RIGHT

        if elapsed_seconds >= max_seconds:
            return score, "timeout"

        if not paused:
            direction = next_dir
            head = (snake[0][0] + direction[0], snake[0][1] + direction[1])

            if not (0 <= head[0] < COLS and 0 <= head[1] < ROWS) or head in snake:
                return score, "gameover"

            snake.insert(0, head)
            if head == food:
                score += 10
                food = random_food(snake)
                if score >= 40 and not celebrated:
                    confetti = spawn_confetti()
                    celebrated = True

                milestone = (score // 50) * 50
                if milestone > 0 and milestone > last_milestone:
                    adjective = random.choice(ADJECTIVES)
                    adj_timer = 25
                    last_milestone = milestone

                if score >= 200 and not fw_triggered:
                    fireworks = spawn_fireworks()
                    fw_triggered = True
                if score >= 100 and not flashed:
                    flash = 12
                    flashed = True
            else:
                snake.pop()

        draw_game(screen, snake, food, score, tries, confetti, fireworks, adjective, adj_timer, flash, elapsed_seconds)

        if adj_timer > 0:
            adj_timer -= 1
        if flash > 0:
            flash -= 1

        if paused:
            pause_str = "PAUSED"
            px_text(screen, pause_str, (WIDTH - px_width(pause_str, 3)) // 2, HEIGHT // 2 - 10, TEXT_COL, s=3)
            pygame.display.flip()

        await asyncio.sleep(0)


async def main():
    pygame.init()
    screen = pygame.display.set_mode((WIDTH, HEIGHT))
    pygame.display.set_caption("SNAKE WEB DEMO")

    tries = 1
    running = True

    while running:
        draw_title_screen(screen)
        should_start = await wait_for_start()
        if not should_start:
            break

        score, result = await run_game(screen, tries)
        if result == "quit":
            break

        draw_game_over(screen, score)
        clock = pygame.time.Clock()
        action = await wait_game_over_action(clock)
        if action == "quit":
            break
        tries += 1

    pygame.quit()


if __name__ == "__main__":
    asyncio.run(main())
